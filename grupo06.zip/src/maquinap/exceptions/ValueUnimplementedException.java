package maquinap.exceptions;

public class ValueUnimplementedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6258268581259060032L;

	public ValueUnimplementedException() {
		super("Value not implemented");
	}

}
