package ast;

public class Nodo {
	public String cod = "";
	public int fila;
}
