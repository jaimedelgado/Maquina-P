package ast;

public class Tipable extends Nodo{
	
	public DTipo0 dtipo0;
}
